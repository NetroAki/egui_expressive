#!/bin/bash
# egui_expressive Illustrator Plugin Installer (macOS)

echo "============================================"
echo " egui_expressive Illustrator Plugin Installer"
echo "============================================"
echo ""

UPIA="/Library/Application Support/Adobe/Adobe Desktop Common/RemoteComponents/UPI/UnifiedPluginInstallerAgent/UnifiedPluginInstallerAgent.app/Contents/MacOS/UnifiedPluginInstallerAgent"

ZXP_FILE=$(ls "$(dirname "$0")/../dist/"*.zxp 2>/dev/null | head -1)
if [ -z "$ZXP_FILE" ]; then
  echo "ERROR: No .zxp found in dist/. Run installer/build_zxp.sh first."
  exit 1
fi

if [ -f "$UPIA" ]; then
    echo "Found UPIA. Installing ZXP..."
    "$UPIA" /install "$ZXP_FILE"
else
    echo "ERROR: UPIA not found."
    echo "To install manually on macOS, use UPIA:"
    echo "  /Library/Application\ Support/Adobe/Adobe\ Desktop\ Common/RemoteComponents/UPI/UnifiedPluginInstallerAgent/UnifiedPluginInstallerAgent /install \"\$ZXP_FILE\""
fi

echo "Enabling CEP debug mode for self-signed extensions..."
defaults write com.adobe.CSXS.10 PlayerDebugMode 1 2>/dev/null || true
defaults write com.adobe.CSXS.11 PlayerDebugMode 1 2>/dev/null || true
defaults write com.adobe.CSXS.12 PlayerDebugMode 1 2>/dev/null || true
echo "CEP debug mode enabled."

