# egui_expressive Illustrator Exporter — linux package

This bundle contains the platform-specific ZXP:

- egui_expressive_export-1.0.0-linux.zxp

Install only on a matching linux host. Do not install this ZXP on another platform because the bundled ai-parser binary is platform-specific.

## Install

Install egui_expressive_export-1.0.0-linux.zxp with your CEP extension manager for this Linux/CEP test host.
