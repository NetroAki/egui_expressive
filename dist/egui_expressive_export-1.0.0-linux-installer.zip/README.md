# egui_expressive Illustrator Exporter — linux package

This bundle contains the platform-specific ZXP:

- egui_expressive_export-1.0.0-linux.zxp

Install only on a matching linux host. Do not install this ZXP on another platform because the bundled ai-parser/vectorizer binary is platform-specific.
